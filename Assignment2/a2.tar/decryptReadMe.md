# Assignment 2

By Guillaume St-Pierre

## Decrypt

### Description

Decrypt - Program that receives an encrypted message and the decryption and key and decrypts it, priting the decrypted message.

### How to use

Compile with `gcc bit_manipulation.c decrypt.c -o decrypt.exe`

Execute with `./decrypt.exe`

### Example

```
Please enter the encrypted message: -75 5 122 35 4 -102 21 -73 31 25 98 10 100 90 -100 53 -18 -81
Please enter the encryption key: 42


Transmitted message:
This is an example
```